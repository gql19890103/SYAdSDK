//
//  SYSplashAdDelegate.h
//  TimeAdSDK
//
//  Created by Amy on 2025/4/15.
//

#import <Foundation/Foundation.h>
#import <TimeAdSDK/SYAdDelegate.h>

NS_ASSUME_NONNULL_BEGIN

@protocol SYSplashAdDelegate <SYAdDelegate>

@optional

@end

NS_ASSUME_NONNULL_END
